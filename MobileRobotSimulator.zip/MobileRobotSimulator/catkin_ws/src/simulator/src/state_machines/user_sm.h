/********************************************************
 *                                                      *
 *                                                      *
 *      user_sm.h			          	*
 *                                                      *
 *							*
 *		FI-UNAM					*
 *		17-2-2019                               *
 *                                                      *
 ********************************************************/

#include <math.h>
#include <stdlib.h>

#define THRESHOLD 20
// State Machine
int user_sm(float intensity, float *light_values, float *observations, int size, float laser_value, int  dest, int obs ,
					movement *movements  ,int *next_state ,float Mag_Advance ,float max_twist, float light_x, float light_y,
					float robot_x, float robot_y, float robot_theta, float *m, float *xo, float *yo, float *xm, float *ym, int *vc)
{

 int state = *next_state;
 int lihgt_low_index = 0;
 int sensor_low_index = size;
 float mayor = 0;
 float menor = laser_value;
 float angle_ligth = 0;
 float angle_obstacle = 0;
 float diference_angle;
 float angle_total;
 float Ep = 1;
 float F_atra[1];
 float F_rep[1];
 float F_total[1];
 float x_atra = 0;
 float y_atra = 0;
 float x_obs = 0;
 float y_obs = 0;
 float norma;
 float constante;
 float menor_sensor;
 int index_menor;
 float n = 2;
 int d = 5;
 int result=0;

 for(int i = 0; i < 8; i++)
		printf("light_values[%d] %f\n",i,light_values[i]);
 for(int i = 0; i < size ; i++ )
		printf("laser observations[%d] %f\n",i,observations[i]);
 for(int i = 0; i < 8; i++){
	 if(mayor < light_values[i]){
		 lihgt_low_index = i;
		 mayor = light_values[i];
	 }
 }
 for(int i = 0; i < size; i++){
	 if(menor > observations[i]){
		 sensor_low_index = i;
		 menor = observations[i];
	 }
 }

 angle_ligth = atan(1)*lihgt_low_index;

 if(sensor_low_index != size){
	 angle_obstacle = (4*atan(1)/(size-1))*sensor_low_index - 2*atan(1);
	 x_obs = menor*cos(angle_obstacle);
	 y_obs = menor*sin(angle_obstacle);
	 norma = sqrt((x_obs*x_obs)+(y_obs*y_obs));
	 constante = (n/norma)*((1/norma)-(1/d))*(1/(norma*norma));

	 F_rep[0] = constante*x_obs;
	 F_rep[1] = constante*y_obs;
 }
 else{
	 F_rep[0] = 0;
	 F_rep[1] = 0;
 }
 printf("Posicion de obstaculo %f, %f \n",x_obs,y_obs);
 printf("Norma de posicion de obstaculo %f \n",norma);
 printf("Constante de obstaculo %f \n",constante);

 x_atra = cos(angle_ligth);
 y_atra = sin(angle_ligth);

 F_atra[0] = Ep*x_atra;
 F_atra[1] = Ep*y_atra;

 F_total[0] = F_atra[0] - F_rep[0];
 F_total[1] = F_atra[1] - F_rep[1];

 angle_total = atan(fabs(F_total[1]/F_total[0]));

 if(F_total[0] > 0 && F_total[1] < 0){
 	angle_total = (8*atan(1)) - angle_total;
 } else{
 	if(F_total[0] < 0 && F_total[1] > 0){
 		angle_total = -angle_total + (4*atan(1));
 	} else{
 		if(F_total[0] < 0 && F_total[1] < 0){
 			angle_total = angle_total + (4*atan(1));
 		} else{
 			angle_total = angle_total;
 		}
 	}
 }

diference_angle = fabs(angle_ligth - angle_obstacle)*180/3.1416;

 printf("Angulo atraccion %f \n", angle_ligth*180/3.1416);
 printf("Angulo repulcion %f \n", angle_obstacle*180/3.1416);
 printf("Diferencia %f \n", diference_angle);
 printf("Angulo total %f \n", angle_total*180/3.1416);

 printf("Fuerza de atraccion %f, %f \n",F_atra[0],F_atra[1]);
 printf("Fuerza de repulcion %f, %f \n",F_rep[0],F_rep[1]);
 printf("Fuerza total %f, %f \n",F_total[0],F_total[1]);
 switch ( state ) {
        case 0:
				if (intensity > THRESHOLD){
						*movements=generate_output(STOP,Mag_Advance,max_twist);
						//printf("Present State: %d STOP\n", state);
						printf("\n **************** Reached light source ******************************\n");
						*next_state = 0;
						result = 1;
				}
				else{
					*next_state = 1;
				}
								break;
				case 1:
				if(angle_ligth == 0 && angle_obstacle != 0 && diference_angle < 5){
					printf("MINIMO LOCAL \n");
					*movements=generate_output(STOP,Mag_Advance,angle_total);
					result = 2;
					*next_state = 3;
				}
				else{
					*movements=generate_output(LEFT,Mag_Advance,angle_total);
					*next_state = 2;
				}
								break;
				case 2:
				*movements=generate_output(FORWARD,Mag_Advance,max_twist);
				*next_state = 0;
								break;
				case 3:
				menor_sensor = observations[0];
				index_menor = 0;
				for(int i = 1; i < size; i++){
					if(observations[i] <= menor_sensor){
						menor_sensor = observations[i];
						index_menor = i;
					}
				}
				if(obs != 0){
					if(index_menor == 0){
						if(menor_sensor > 0.8*laser_value)
							*next_state = 4;
						else{
							if(menor_sensor < 0.65*laser_value)
								*next_state = 5;
							else{
								*movements=generate_output(FORWARD,0.15*Mag_Advance,max_twist);
							}
						}
					}
					else{
						*next_state = 3;
						*movements=generate_output(LEFT,Mag_Advance,0.1*max_twist);
					}
				}
				else{
					*next_state = 2;
				}
								break;
				case 4:
				menor_sensor = observations[0];
				index_menor = 0;
				for(int i = 1; i < size; i++){
					if(observations[i] <= menor_sensor){
						menor_sensor = observations[i];
						index_menor = i;
					}
				}
				if(index_menor == 9){
					*movements=generate_output(FORWARD,0.15*Mag_Advance,max_twist);
					*next_state = 3;
				}
				else{
					*movements=generate_output(RIGHT,Mag_Advance,0.1*max_twist);
					*next_state = 4;
				}
								break;
				case 5:
				menor_sensor = observations[0];
				index_menor = 0;
				for(int i = 1; i < size; i++){
					if(observations[i] <= menor_sensor){
						menor_sensor = observations[i];
						index_menor = i;
					}
				}
				if(index_menor == 9){
					*movements=generate_output(BACKWARD,0.15*Mag_Advance,max_twist);
					*next_state = 3;
				}
				else{
					*movements=generate_output(RIGHT,Mag_Advance,0.1*max_twist);
					*next_state = 5;
				}
								break;

	default:
		//printf("State %d not defined used ", state);
                *movements=generate_output(STOP,Mag_Advance,max_twist);
                *next_state = 0;
                break;
 }
printf("Next State: %d\n", *next_state);
return result;
}
