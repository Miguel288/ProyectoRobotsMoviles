#!/bin/bash
sudo apt-get  install ros-melodic-turtlebot-*
sudo apt-get install libcgal-qt5-dev libcgal-dev 
find . -name "*.py" | xargs chmod +x



